/*
 * Copyright (c) 2025 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef RESOURCE_TABLE_H
#define RESOURCE_TABLE_H

#include<stdint.h>

namespace OHOS {
const int32_t STRING_ABILITY_DESC = 0x0100000c;
const int32_t STRING_ABILITY_LABEL = 0x0100000d;
const int32_t STRING_ADD_SUBSCRIPTION = 0x0100000e;
const int32_t STRING_AMOUNT = 0x0100000f;
const int32_t STRING_APP_NAME = 0x01000001;
const int32_t STRING_CANCEL = 0x01000010;
const int32_t STRING_CATEGORY = 0x01000011;
const int32_t STRING_CLOUD = 0x01000012;
const int32_t STRING_CONFIRM = 0x01000013;
const int32_t STRING_CYCLE = 0x01000014;
const int32_t STRING_DAYS_LEFT = 0x01000015;
const int32_t STRING_DELETE = 0x01000016;
const int32_t STRING_DELETE_CONFIRM = 0x01000017;
const int32_t STRING_DUE_TODAY = 0x01000018;
const int32_t STRING_EDIT_SUBSCRIPTION = 0x01000019;
const int32_t STRING_FIRST_DATE = 0x0100001a;
const int32_t STRING_MODULE_DESC = 0x0100000a;
const int32_t STRING_MONTHLY = 0x0100001b;
const int32_t STRING_MUSIC = 0x0100001c;
const int32_t STRING_NEXT_DATE = 0x0100001d;
const int32_t STRING_NO_EVENTS = 0x0100001e;
const int32_t STRING_NO_SUBSCRIPTIONS = 0x0100001f;
const int32_t STRING_OTHER = 0x01000020;
const int32_t STRING_OVERDUE = 0x01000021;
const int32_t STRING_PERMISSION_REMINDER_REASON = 0x01000022;
const int32_t STRING_QUARTERLY = 0x01000023;
const int32_t STRING_REMIND_DAYS = 0x01000024;
const int32_t STRING_REMINDER_CONTENT = 0x01000025;
const int32_t STRING_REMINDER_TITLE = 0x01000026;
const int32_t STRING_SAVE = 0x01000027;
const int32_t STRING_SUBSCRIPTION_NAME = 0x01000028;
const int32_t STRING_TAB_CALENDAR = 0x01000029;
const int32_t STRING_TAB_STATS = 0x0100002a;
const int32_t STRING_TAB_SUBSCRIPTION = 0x0100002b;
const int32_t STRING_THIS_MONTH = 0x0100002c;
const int32_t STRING_THIS_YEAR = 0x0100002d;
const int32_t STRING_TOOL = 0x0100002e;
const int32_t STRING_TOTAL = 0x0100002f;
const int32_t STRING_VIDEO = 0x01000030;
const int32_t STRING_YEARLY = 0x01000031;
const int32_t COLOR_BACKGROUND_COLOR = 0x01000032;
const int32_t COLOR_BORDER_COLOR = 0x01000033;
const int32_t COLOR_CARD_BACKGROUND = 0x01000034;
const int32_t COLOR_CLOUD_COLOR = 0x01000035;
const int32_t COLOR_DANGER_COLOR = 0x01000036;
const int32_t COLOR_MUSIC_COLOR = 0x01000037;
const int32_t COLOR_OTHER_COLOR = 0x01000038;
const int32_t COLOR_PRIMARY_COLOR = 0x01000039;
const int32_t COLOR_START_WINDOW_BACKGROUND = 0x01000004;
const int32_t COLOR_SUCCESS_COLOR = 0x0100003a;
const int32_t COLOR_TEXT_HINT = 0x0100003b;
const int32_t COLOR_TEXT_PRIMARY = 0x0100003c;
const int32_t COLOR_TEXT_SECONDARY = 0x0100003d;
const int32_t COLOR_TOOL_COLOR = 0x0100003e;
const int32_t COLOR_VIDEO_COLOR = 0x0100003f;
const int32_t COLOR_WARNING_COLOR = 0x01000040;
const int32_t FLOAT_PAGE_TEXT_FONT_SIZE = 0x0100000b;
const int32_t MEDIA_BACKGROUND = 0x01000003;
const int32_t MEDIA_FOREGROUND = 0x01000000;
const int32_t MEDIA_LAYERED_IMAGE = 0x01000002;
const int32_t MEDIA_STARTICON = 0x01000007;
const int32_t PROFILE_BACKUP_CONFIG = 0x01000006;
const int32_t PROFILE_MAIN_PAGES = 0x01000005;
}
#endif