if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface AddSubscriptionDialog_Params {
    controller?: CustomDialogController;
    subscription?: Subscription | null;
    onSave?: (request: CreateSubscriptionRequest) => void;
    onUpdate?: (id: string, request: CreateSubscriptionRequest) => void;
    onDelete?: (id: string) => void;
    name?: string;
    amount?: string;
    cycleType?: CycleType;
    firstDate?: string;
    category?: Category;
    remindDays?: number;
    isActive?: boolean;
}
import { DateUtils, CATEGORY_CONFIGS, CYCLE_CONFIGS } from "@normalized:N&&&entry/src/main/ets/model/Subscription&";
import type { Subscription, CreateSubscriptionRequest, Category, CycleType } from "@normalized:N&&&entry/src/main/ets/model/Subscription&";
import { Colors, FontSizes, Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
export class AddSubscriptionDialog extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.controller = undefined;
        this.subscription = null;
        this.onSave = () => { };
        this.onUpdate = () => { };
        this.onDelete = () => { };
        this.__name = new ObservedPropertySimplePU('', this, "name");
        this.__amount = new ObservedPropertySimplePU('', this, "amount");
        this.__cycleType = new ObservedPropertySimplePU('monthly', this, "cycleType");
        this.__firstDate = new ObservedPropertySimplePU(DateUtils.formatDate(new Date()), this, "firstDate");
        this.__category = new ObservedPropertySimplePU('other', this, "category");
        this.__remindDays = new ObservedPropertySimplePU(Constants.DEFAULT_REMIND_DAYS, this, "remindDays");
        this.__isActive = new ObservedPropertySimplePU(true, this, "isActive");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: AddSubscriptionDialog_Params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.subscription !== undefined) {
            this.subscription = params.subscription;
        }
        if (params.onSave !== undefined) {
            this.onSave = params.onSave;
        }
        if (params.onUpdate !== undefined) {
            this.onUpdate = params.onUpdate;
        }
        if (params.onDelete !== undefined) {
            this.onDelete = params.onDelete;
        }
        if (params.name !== undefined) {
            this.name = params.name;
        }
        if (params.amount !== undefined) {
            this.amount = params.amount;
        }
        if (params.cycleType !== undefined) {
            this.cycleType = params.cycleType;
        }
        if (params.firstDate !== undefined) {
            this.firstDate = params.firstDate;
        }
        if (params.category !== undefined) {
            this.category = params.category;
        }
        if (params.remindDays !== undefined) {
            this.remindDays = params.remindDays;
        }
        if (params.isActive !== undefined) {
            this.isActive = params.isActive;
        }
    }
    updateStateVars(params: AddSubscriptionDialog_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__name.purgeDependencyOnElmtId(rmElmtId);
        this.__amount.purgeDependencyOnElmtId(rmElmtId);
        this.__cycleType.purgeDependencyOnElmtId(rmElmtId);
        this.__firstDate.purgeDependencyOnElmtId(rmElmtId);
        this.__category.purgeDependencyOnElmtId(rmElmtId);
        this.__remindDays.purgeDependencyOnElmtId(rmElmtId);
        this.__isActive.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__name.aboutToBeDeleted();
        this.__amount.aboutToBeDeleted();
        this.__cycleType.aboutToBeDeleted();
        this.__firstDate.aboutToBeDeleted();
        this.__category.aboutToBeDeleted();
        this.__remindDays.aboutToBeDeleted();
        this.__isActive.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private controller: CustomDialogController;
    setController(ctr: CustomDialogController) {
        this.controller = ctr;
    }
    private subscription: Subscription | null;
    private onSave: (request: CreateSubscriptionRequest) => void;
    private onUpdate: (id: string, request: CreateSubscriptionRequest) => void;
    private onDelete: (id: string) => void;
    private __name: ObservedPropertySimplePU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    private __amount: ObservedPropertySimplePU<string>;
    get amount() {
        return this.__amount.get();
    }
    set amount(newValue: string) {
        this.__amount.set(newValue);
    }
    private __cycleType: ObservedPropertySimplePU<CycleType>;
    get cycleType() {
        return this.__cycleType.get();
    }
    set cycleType(newValue: CycleType) {
        this.__cycleType.set(newValue);
    }
    private __firstDate: ObservedPropertySimplePU<string>;
    get firstDate() {
        return this.__firstDate.get();
    }
    set firstDate(newValue: string) {
        this.__firstDate.set(newValue);
    }
    private __category: ObservedPropertySimplePU<Category>;
    get category() {
        return this.__category.get();
    }
    set category(newValue: Category) {
        this.__category.set(newValue);
    }
    private __remindDays: ObservedPropertySimplePU<number>;
    get remindDays() {
        return this.__remindDays.get();
    }
    set remindDays(newValue: number) {
        this.__remindDays.set(newValue);
    }
    private __isActive: ObservedPropertySimplePU<boolean>;
    get isActive() {
        return this.__isActive.get();
    }
    set isActive(newValue: boolean) {
        this.__isActive.set(newValue);
    }
    aboutToAppear() {
        if (this.subscription) {
            this.name = this.subscription.name;
            this.amount = this.subscription.amount.toString();
            this.cycleType = this.subscription.cycleType;
            this.firstDate = this.subscription.firstDate;
            this.category = this.subscription.category;
            this.remindDays = this.subscription.remindDays;
            this.isActive = this.subscription.isActive;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(36:5)", "entry");
            Column.width('100%');
            Column.backgroundColor(Colors.CARD_BACKGROUND);
            Column.borderRadius({ topLeft: 20, topRight: 20 });
            Column.height('90%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题栏
            Row.create();
            Row.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(38:7)", "entry");
            // 标题栏
            Row.width('100%');
            // 标题栏
            Row.padding({ left: 20, right: 12, top: 16, bottom: 16 });
            // 标题栏
            Row.alignItems(VerticalAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.subscription ? '编辑订阅' : '添加订阅');
            Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(39:9)", "entry");
            Text.fontSize(FontSizes.LARGE);
            Text.fontColor(Colors.TEXT_PRIMARY);
            Text.fontWeight(FontWeight.Medium);
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(45:9)", "entry");
            Button.width(32);
            Button.height(32);
            Button.backgroundColor(Color.Transparent);
            Button.onClick(() => {
                this.controller.close();
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('×');
            Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(46:11)", "entry");
            Text.fontSize(24);
            Text.fontColor(Colors.TEXT_SECONDARY);
        }, Text);
        Text.pop();
        Button.pop();
        // 标题栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(61:7)", "entry");
            Scroll.layoutWeight(1);
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(62:9)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20, bottom: 20 });
        }, Column);
        // 订阅名称
        this.InputItem.bind(this)('订阅名称', '请输入订阅名称', this.name, (value) => {
            this.name = value;
        }, true);
        // 金额
        this.InputItem.bind(this)('金额（元）', '请输入金额', this.amount, (value) => {
            this.amount = value;
        }, false, 'decimal');
        // 周期选择
        this.SelectItem.bind(this)('订阅周期', CYCLE_CONFIGS.map(c => c.label), CYCLE_CONFIGS.findIndex(c => c.type === this.cycleType), (index) => {
            this.cycleType = CYCLE_CONFIGS[index].type;
        });
        // 首次扣费日
        this.DateItem.bind(this)('首次扣费日', this.firstDate, (date) => {
            this.firstDate = date;
        });
        // 分类选择
        this.SelectItem.bind(this)('分类', CATEGORY_CONFIGS.map(c => `${c.emoji} ${c.label}`), CATEGORY_CONFIGS.findIndex(c => c.name === this.category), (index) => {
            this.category = CATEGORY_CONFIGS[index].name;
        });
        // 提前提醒天数
        this.RemindDaysItem.bind(this)();
        // 启用开关
        this.SwitchItem.bind(this)('启用提醒', this.isActive, (value) => {
            this.isActive = value;
        });
        // 下次扣费日预览
        this.NextDatePreview.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 删除按钮
            if (this.subscription) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('删除订阅');
                        Button.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(101:13)", "entry");
                        Button.fontSize(FontSizes.NORMAL);
                        Button.fontColor(Colors.DANGER);
                        Button.width('100%');
                        Button.height(44);
                        Button.backgroundColor(Colors.DANGER + '15');
                        Button.borderRadius(8);
                        Button.margin({ top: 16 });
                        Button.onClick(() => {
                            this.onDelete(this.subscription!.id);
                            this.controller.close();
                        });
                    }, Button);
                    Button.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Scroll.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 保存按钮
            Button.createWithLabel('保存');
            Button.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(122:7)", "entry");
            // 保存按钮
            Button.fontSize(FontSizes.MEDIUM);
            // 保存按钮
            Button.fontColor('#FFFFFF');
            // 保存按钮
            Button.width('100%');
            // 保存按钮
            Button.height(48);
            // 保存按钮
            Button.backgroundColor(Colors.PRIMARY);
            // 保存按钮
            Button.borderRadius(24);
            // 保存按钮
            Button.margin({ left: 20, right: 20, bottom: 20 });
            // 保存按钮
            Button.onClick(() => {
                this.handleSave();
            });
        }, Button);
        // 保存按钮
        Button.pop();
        Column.pop();
    }
    InputItem(title: string, placeholder: string, value: string, onChange: (value: string) => void, required: boolean = false, inputType: string = 'text', parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(142:5)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 16 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(143:7)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(144:9)", "entry");
            Text.fontSize(FontSizes.NORMAL);
            Text.fontColor(Colors.TEXT_SECONDARY);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (required) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('*');
                        Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(148:11)", "entry");
                        Text.fontSize(FontSizes.NORMAL);
                        Text.fontColor(Colors.DANGER);
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: placeholder, text: value });
            TextInput.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(156:7)", "entry");
            TextInput.fontSize(FontSizes.NORMAL);
            TextInput.height(44);
            TextInput.backgroundColor(Colors.BACKGROUND);
            TextInput.borderRadius(8);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.type(inputType === 'decimal' ? InputType.Number : InputType.Normal);
            TextInput.onChange((text) => {
                onChange(text);
            });
        }, TextInput);
        Column.pop();
    }
    SelectItem(title: string, options: string[], selectedIndex: number, onSelect: (index: number) => void, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(173:5)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 16 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(174:7)", "entry");
            Text.fontSize(FontSizes.NORMAL);
            Text.fontColor(Colors.TEXT_SECONDARY);
            Text.width('100%');
            Text.margin({ bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(180:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const option = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(option);
                    Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(182:11)", "entry");
                    Text.fontSize(FontSizes.SMALL);
                    Text.fontColor(selectedIndex === index ? '#FFFFFF' : Colors.TEXT_PRIMARY);
                    Text.backgroundColor(selectedIndex === index ? Colors.PRIMARY : Colors.BACKGROUND);
                    Text.padding({ left: 12, right: 12, top: 8, bottom: 8 });
                    Text.borderRadius(16);
                    Text.margin({ right: 8 });
                    Text.onClick(() => {
                        onSelect(index);
                    });
                }, Text);
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, options, forEachItemGenFunction, (option: string, index: number) => option + '_' + index.toString(), true, true);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Column.pop();
    }
    DateItem(title: string, value: string, onChange: (date: string) => void, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(202:5)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 16 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(203:7)", "entry");
            Text.fontSize(FontSizes.NORMAL);
            Text.fontColor(Colors.TEXT_SECONDARY);
            Text.width('100%');
            Text.margin({ bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(209:7)", "entry");
            Row.width('100%');
            Row.height(44);
            Row.padding({ left: 12, right: 12 });
            Row.backgroundColor(Colors.BACKGROUND);
            Row.borderRadius(8);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(value);
            Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(210:9)", "entry");
            Text.fontSize(FontSizes.NORMAL);
            Text.fontColor(Colors.TEXT_PRIMARY);
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('选择日期');
            Button.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(215:9)", "entry");
            Button.fontSize(FontSizes.SMALL);
            Button.fontColor(Colors.PRIMARY);
            Button.backgroundColor(Color.Transparent);
            Button.onClick(() => {
                this.showDatePicker(onChange);
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    RemindDaysItem(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(235:5)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 16 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(236:7)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('提前提醒');
            Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(237:9)", "entry");
            Text.fontSize(FontSizes.NORMAL);
            Text.fontColor(Colors.TEXT_SECONDARY);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.remindDays} 天`);
            Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(240:9)", "entry");
            Text.fontSize(FontSizes.NORMAL);
            Text.fontColor(Colors.TEXT_PRIMARY);
            Text.margin({ left: 8 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(248:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const days = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(`${days}天`);
                    Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(250:11)", "entry");
                    Text.fontSize(FontSizes.SMALL);
                    Text.fontColor(this.remindDays === days ? '#FFFFFF' : Colors.TEXT_PRIMARY);
                    Text.backgroundColor(this.remindDays === days ? Colors.PRIMARY : Colors.BACKGROUND);
                    Text.padding({ left: 10, right: 10, top: 6, bottom: 6 });
                    Text.borderRadius(12);
                    Text.margin({ right: 6 });
                    Text.onClick(() => {
                        this.remindDays = days;
                    });
                }, Text);
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, Constants.REMIND_DAYS_OPTIONS, forEachItemGenFunction, (days: number, index: number) => days.toString() + '_' + index.toString(), true, true);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Column.pop();
    }
    SwitchItem(title: string, value: boolean, onChange: (value: boolean) => void, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(270:5)", "entry");
            Row.width('100%');
            Row.height(44);
            Row.padding({ left: 12, right: 12 });
            Row.backgroundColor(Colors.BACKGROUND);
            Row.borderRadius(8);
            Row.margin({ bottom: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(271:7)", "entry");
            Text.fontSize(FontSizes.NORMAL);
            Text.fontColor(Colors.TEXT_SECONDARY);
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: value });
            Toggle.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(276:7)", "entry");
            Toggle.selectedColor(Colors.PRIMARY);
            Toggle.onChange((isOn: boolean) => {
                onChange(isOn);
            });
        }, Toggle);
        Toggle.pop();
        Row.pop();
    }
    NextDatePreview(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(292:5)", "entry");
            Row.width('100%');
            Row.height(44);
            Row.padding({ left: 12, right: 12 });
            Row.backgroundColor(Colors.PRIMARY + '10');
            Row.borderRadius(8);
            Row.margin({ bottom: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('下次扣费日');
            Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(293:7)", "entry");
            Text.fontSize(FontSizes.NORMAL);
            Text.fontColor(Colors.TEXT_SECONDARY);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.getNextDate());
            Text.debugLine("entry/src/main/ets/view/AddSubscriptionDialog.ets(296:7)", "entry");
            Text.fontSize(FontSizes.NORMAL);
            Text.fontColor(Colors.PRIMARY);
            Text.fontWeight(FontWeight.Medium);
            Text.margin({ left: 8 });
        }, Text);
        Text.pop();
        Row.pop();
    }
    private getNextDate(): string {
        if (!this.firstDate)
            return '-';
        return DateUtils.calculateNextDate(this.firstDate, this.cycleType);
    }
    private showDatePicker(onChange: (date: string) => void): void {
        // 使用 HarmonyOS DatePicker 组件
        DatePickerDialog.show({
            start: new Date('2020-01-01'),
            end: new Date('2030-12-31'),
            selected: DateUtils.parseDate(this.firstDate),
            onAccept: (date: DatePickerResult) => {
                const selectedDate = `${date.year}-${String(date.month! + 1).padStart(2, '0')}-${String(date.day!).padStart(2, '0')}`;
                onChange(selectedDate);
            }
        });
    }
    private handleSave(): void {
        // 验证
        if (!this.name.trim()) {
            return;
        }
        const amountValue = parseFloat(this.amount);
        if (isNaN(amountValue) || amountValue <= 0) {
            return;
        }
        const request: CreateSubscriptionRequest = {
            name: this.name.trim(),
            amount: amountValue,
            cycleType: this.cycleType,
            firstDate: this.firstDate,
            category: this.category,
            remindDays: this.remindDays,
            isActive: this.isActive
        };
        if (this.subscription) {
            this.onUpdate(this.subscription.id, request);
        }
        else {
            this.onSave(request);
        }
        this.controller.close();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
