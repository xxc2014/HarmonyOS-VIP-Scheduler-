if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface StatsView_Params {
    subscriptions?: Subscription[];
    monthTotal?: number;
    yearTotal?: number;
    monthByCategory?: Map<string, number>;
    yearByCategory?: Map<string, number>;
    monthSubscriptionCount?: number;
    yearSubscriptionCount?: number;
}
import { CATEGORY_CONFIGS } from "@normalized:N&&&entry/src/main/ets/model/Subscription&";
import type { Subscription, CategoryConfig } from "@normalized:N&&&entry/src/main/ets/model/Subscription&";
import { Colors, Sizes, FontSizes } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
export class StatsView extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__subscriptions = new SynchedPropertyObjectTwoWayPU(params.subscriptions, this, "subscriptions");
        this.__monthTotal = new ObservedPropertySimplePU(0, this, "monthTotal");
        this.__yearTotal = new ObservedPropertySimplePU(0, this, "yearTotal");
        this.__monthByCategory = new ObservedPropertyObjectPU(new Map(), this, "monthByCategory");
        this.__yearByCategory = new ObservedPropertyObjectPU(new Map(), this, "yearByCategory");
        this.__monthSubscriptionCount = new ObservedPropertySimplePU(0, this, "monthSubscriptionCount");
        this.__yearSubscriptionCount = new ObservedPropertySimplePU(0, this, "yearSubscriptionCount");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: StatsView_Params) {
        if (params.monthTotal !== undefined) {
            this.monthTotal = params.monthTotal;
        }
        if (params.yearTotal !== undefined) {
            this.yearTotal = params.yearTotal;
        }
        if (params.monthByCategory !== undefined) {
            this.monthByCategory = params.monthByCategory;
        }
        if (params.yearByCategory !== undefined) {
            this.yearByCategory = params.yearByCategory;
        }
        if (params.monthSubscriptionCount !== undefined) {
            this.monthSubscriptionCount = params.monthSubscriptionCount;
        }
        if (params.yearSubscriptionCount !== undefined) {
            this.yearSubscriptionCount = params.yearSubscriptionCount;
        }
    }
    updateStateVars(params: StatsView_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__subscriptions.purgeDependencyOnElmtId(rmElmtId);
        this.__monthTotal.purgeDependencyOnElmtId(rmElmtId);
        this.__yearTotal.purgeDependencyOnElmtId(rmElmtId);
        this.__monthByCategory.purgeDependencyOnElmtId(rmElmtId);
        this.__yearByCategory.purgeDependencyOnElmtId(rmElmtId);
        this.__monthSubscriptionCount.purgeDependencyOnElmtId(rmElmtId);
        this.__yearSubscriptionCount.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__subscriptions.aboutToBeDeleted();
        this.__monthTotal.aboutToBeDeleted();
        this.__yearTotal.aboutToBeDeleted();
        this.__monthByCategory.aboutToBeDeleted();
        this.__yearByCategory.aboutToBeDeleted();
        this.__monthSubscriptionCount.aboutToBeDeleted();
        this.__yearSubscriptionCount.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __subscriptions: SynchedPropertySimpleOneWayPU<Subscription[]>;
    get subscriptions() {
        return this.__subscriptions.get();
    }
    set subscriptions(newValue: Subscription[]) {
        this.__subscriptions.set(newValue);
    }
    private __monthTotal: ObservedPropertySimplePU<number>;
    get monthTotal() {
        return this.__monthTotal.get();
    }
    set monthTotal(newValue: number) {
        this.__monthTotal.set(newValue);
    }
    private __yearTotal: ObservedPropertySimplePU<number>;
    get yearTotal() {
        return this.__yearTotal.get();
    }
    set yearTotal(newValue: number) {
        this.__yearTotal.set(newValue);
    }
    private __monthByCategory: ObservedPropertyObjectPU<Map<string, number>>;
    get monthByCategory() {
        return this.__monthByCategory.get();
    }
    set monthByCategory(newValue: Map<string, number>) {
        this.__monthByCategory.set(newValue);
    }
    private __yearByCategory: ObservedPropertyObjectPU<Map<string, number>>;
    get yearByCategory() {
        return this.__yearByCategory.get();
    }
    set yearByCategory(newValue: Map<string, number>) {
        this.__yearByCategory.set(newValue);
    }
    private __monthSubscriptionCount: ObservedPropertySimplePU<number>;
    get monthSubscriptionCount() {
        return this.__monthSubscriptionCount.get();
    }
    set monthSubscriptionCount(newValue: number) {
        this.__monthSubscriptionCount.set(newValue);
    }
    private __yearSubscriptionCount: ObservedPropertySimplePU<number>;
    get yearSubscriptionCount() {
        return this.__yearSubscriptionCount.get();
    }
    set yearSubscriptionCount(newValue: number) {
        this.__yearSubscriptionCount.set(newValue);
    }
    aboutToAppear() {
        this.calculateStats();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/view/StatsView.ets(23:5)", "entry");
            Scroll.width('100%');
            Scroll.height('100%');
            Scroll.backgroundColor(Colors.BACKGROUND);
            Scroll.align(Alignment.Top);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/StatsView.ets(24:7)", "entry");
            Column.width('100%');
            Column.padding(16);
        }, Column);
        // 本月统计卡片
        this.MonthStatsCard.bind(this)();
        // 本年统计卡片
        this.YearStatsCard.bind(this)();
        // 分类明细
        this.CategoryDetail.bind(this)();
        Column.pop();
        Scroll.pop();
    }
    MonthStatsCard(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/StatsView.ets(45:5)", "entry");
            Column.width('100%');
            Column.padding(Sizes.CARD_PADDING);
            Column.backgroundColor(Colors.CARD_BACKGROUND);
            Column.borderRadius(Sizes.CARD_RADIUS);
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('本月预计');
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(46:7)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(Colors.TEXT_SECONDARY);
            Text.width('100%');
            Text.margin({ bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/StatsView.ets(52:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('¥');
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(53:9)", "entry");
            Text.fontSize(FontSizes.XLARGE);
            Text.fontColor(Colors.PRIMARY);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.monthTotal.toFixed(2));
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(56:9)", "entry");
            Text.fontSize(32);
            Text.fontColor(Colors.PRIMARY);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/StatsView.ets(63:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.monthSubscriptionCount} 个订阅`);
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(64:9)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(Colors.TEXT_HINT);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(' · ');
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(67:9)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(Colors.TEXT_HINT);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`日均 ${(this.monthTotal / 30).toFixed(2)} 元`);
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(70:9)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(Colors.TEXT_HINT);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
    }
    YearStatsCard(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/StatsView.ets(86:5)", "entry");
            Column.width('100%');
            Column.padding(Sizes.CARD_PADDING);
            Column.backgroundColor(Colors.CARD_BACKGROUND);
            Column.borderRadius(Sizes.CARD_RADIUS);
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('本年预计');
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(87:7)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(Colors.TEXT_SECONDARY);
            Text.width('100%');
            Text.margin({ bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/StatsView.ets(93:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('¥');
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(94:9)", "entry");
            Text.fontSize(FontSizes.XLARGE);
            Text.fontColor(Colors.WARNING);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.yearTotal.toFixed(2));
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(97:9)", "entry");
            Text.fontSize(32);
            Text.fontColor(Colors.WARNING);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/StatsView.ets(104:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.yearSubscriptionCount} 个订阅`);
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(105:9)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(Colors.TEXT_HINT);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(' · ');
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(108:9)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(Colors.TEXT_HINT);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`月均 ${(this.yearTotal / 12).toFixed(2)} 元`);
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(111:9)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(Colors.TEXT_HINT);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
    }
    CategoryDetail(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/StatsView.ets(127:5)", "entry");
            Column.width('100%');
            Column.padding(Sizes.CARD_PADDING);
            Column.backgroundColor(Colors.CARD_BACKGROUND);
            Column.borderRadius(Sizes.CARD_RADIUS);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('分类明细');
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(128:7)", "entry");
            Text.fontSize(FontSizes.MEDIUM);
            Text.fontColor(Colors.TEXT_PRIMARY);
            Text.fontWeight(FontWeight.Medium);
            Text.width('100%');
            Text.margin({ bottom: 12 });
        }, Text);
        Text.pop();
        // 本月分类
        this.CategorySection.bind(this)('本月', ObservedObject.GetRawObject(this.monthByCategory), this.monthTotal);
        // 本年分类
        this.CategorySection.bind(this)('本年', ObservedObject.GetRawObject(this.yearByCategory), this.yearTotal);
        Column.pop();
    }
    CategorySection(title: string, categoryMap: Map<string, number>, total: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/StatsView.ets(149:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(150:7)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(Colors.TEXT_HINT);
            Text.width('100%');
            Text.margin({ top: 8, bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const config = _item;
                // 使用箭头函数参数获取amount，避免在ForEach中直接使用let声明
                this.CategoryRow.bind(this)(config.name, config.label, config.emoji, config.color, categoryMap.get(config.name) || 0, total);
            };
            this.forEachUpdateFunction(elmtId, CATEGORY_CONFIGS, forEachItemGenFunction, (config: CategoryConfig) => config.name, false, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
    }
    CategoryRow(category: string, label: string, emoji: string, color: string, amount: number, total: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/StatsView.ets(165:5)", "entry");
            Row.width('100%');
            Row.padding({ top: 8, bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(emoji);
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(166:7)", "entry");
            Text.fontSize(20);
            Text.width(32);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(170:7)", "entry");
            Text.fontSize(FontSizes.NORMAL);
            Text.fontColor(Colors.TEXT_PRIMARY);
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/StatsView.ets(175:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`¥${amount.toFixed(2)}`);
            Text.debugLine("entry/src/main/ets/view/StatsView.ets(176:9)", "entry");
            Text.fontSize(FontSizes.NORMAL);
            Text.fontColor(Colors.TEXT_PRIMARY);
            Text.fontWeight(FontWeight.Medium);
            Text.alignSelf(ItemAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (total > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${((amount / total) * 100).toFixed(1)}%`);
                        Text.debugLine("entry/src/main/ets/view/StatsView.ets(183:11)", "entry");
                        Text.fontSize(FontSizes.SMALL);
                        Text.fontColor(Colors.TEXT_HINT);
                        Text.alignSelf(ItemAlign.End);
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Row.pop();
    }
    // 计算统计数据
    private calculateStats(): void {
        const now = new Date();
        const currentYear = now.getFullYear();
        const currentMonth = now.getMonth() + 1;
        // 本月统计
        let monthTotal = 0;
        let monthSubscriptionCount = 0;
        let monthByCategory = new Map<string, number>();
        // 本年统计
        let yearTotal = 0;
        let yearSubscriptionCount = 0;
        let yearByCategory = new Map<string, number>();
        // 本月前缀
        const monthPrefix = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;
        // 本年前缀
        const yearPrefix = `${currentYear}`;
        for (const sub of this.subscriptions) {
            if (!sub.isActive)
                continue;
            // 检查是否为本月扣费（按nextDate匹配）
            if (sub.nextDate.startsWith(monthPrefix)) {
                monthTotal += sub.amount;
                monthSubscriptionCount++;
                const current = monthByCategory.get(sub.category) || 0;
                monthByCategory.set(sub.category, current + sub.amount);
            }
            // 检查是否为本年扣费（按nextDate匹配当年）
            if (sub.nextDate.startsWith(yearPrefix)) {
                yearTotal += sub.amount;
                yearSubscriptionCount++;
                const current = yearByCategory.get(sub.category) || 0;
                yearByCategory.set(sub.category, current + sub.amount);
            }
        }
        this.monthTotal = monthTotal;
        this.monthSubscriptionCount = monthSubscriptionCount;
        this.monthByCategory = monthByCategory;
        this.yearTotal = yearTotal;
        this.yearSubscriptionCount = yearSubscriptionCount;
        this.yearByCategory = yearByCategory;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
