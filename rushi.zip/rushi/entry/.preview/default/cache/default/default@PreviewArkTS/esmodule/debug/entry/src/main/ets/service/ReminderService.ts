import reminderAgentManager from "@ohos:reminderAgentManager";
import wantAgent from "@ohos:wantAgent";
import type Want from "@ohos:app.ability.Want";
import { DateUtils } from "@normalized:N&&&entry/src/main/ets/model/Subscription&";
import type { Subscription } from "@normalized:N&&&entry/src/main/ets/model/Subscription&";
interface ReminderRequestWithId extends reminderAgentManager.ReminderRequest {
    id: number;
}
interface WantAgentInfo {
    wants: Want[];
    operationType: wantAgent.OperationType;
    requestCode: number;
    wantAgentFlags: wantAgent.WantAgentFlags[];
}
/**
 * 提醒服务 - 管理本地提醒通知
 * 注意：不依赖内存Map追踪提醒ID，重启时通过cancelAllReminders + createAllReminders刷新
 */
export class ReminderService {
    private static instance: ReminderService = new ReminderService();
    private constructor() { }
    /**
     * 获取单例实例
     */
    static getInstance(): ReminderService {
        return ReminderService.instance;
    }
    /**
     * 为订阅创建提醒
     */
    async createReminder(subscription: Subscription): Promise<void> {
        if (!subscription.isActive) {
            return;
        }
        // 计算提醒时间
        const nextDate = DateUtils.parseDate(subscription.nextDate);
        const reminderDate = new Date(nextDate);
        reminderDate.setDate(reminderDate.getDate() - subscription.remindDays);
        reminderDate.setHours(9, 0, 0, 0); // 设置为早上9点提醒
        // 如果提醒时间已过，不创建
        if (reminderDate.getTime() <= Date.now()) {
            return;
        }
        try {
            // 创建wantAgent
            const wantAgentInfo: WantAgentInfo = {
                wants: [
                    {
                        bundleName: 'com.example.renewalmanager',
                        abilityName: 'EntryAbility'
                    } as Want
                ] as Want[],
                operationType: wantAgent.OperationType.START_ABILITY,
                requestCode: 0,
                wantAgentFlags: [wantAgent.WantAgentFlags.UPDATE_PRESENT_FLAG] as wantAgent.WantAgentFlags[]
            };
            const agent = await wantAgent.getWantAgent(wantAgentInfo) as reminderAgentManager.WantAgent;
            // 创建提醒
            const reminderRequest: reminderAgentManager.ReminderRequestCalendar = {
                reminderType: reminderAgentManager.ReminderType.REMINDER_TYPE_CALENDAR,
                dateTime: {
                    year: reminderDate.getFullYear(),
                    month: reminderDate.getMonth() + 1,
                    day: reminderDate.getDate(),
                    hour: reminderDate.getHours(),
                    minute: reminderDate.getMinutes()
                },
                repeatMonths: [],
                repeatDays: [],
                title: '续费提醒',
                content: `${subscription.name} 将在 ${subscription.remindDays} 天后续费，金额 ${subscription.amount.toFixed(2)} 元`,
                wantAgent: agent,
                slotType: 0
            };
            const reminderId = await reminderAgentManager.publishReminder(reminderRequest);
            console.info(`Created reminder for ${subscription.name}, reminderId: ${reminderId}`);
        }
        catch (error) {
            console.error('Create reminder error:', error);
        }
    }
    /**
     * 移除订阅的提醒（通过查询所有提醒来定位）
     * 使用更严格的匹配方式：subscriptionId或唯一标识
     */
    async removeReminder(subscription: Subscription): Promise<void> {
        try {
            const allReminders = await reminderAgentManager.getValidReminders();
            for (const reminder of allReminders) {
                // 通过内容精确匹配订阅名称（使用精确匹配而非includes避免误匹配）
                if (reminder.content) {
                    // 匹配格式："{订阅名} 将在 X 天后续费..."
                    const matchPattern = `^${subscription.name} 将在 \\d+ 天后续费`;
                    const regex = new RegExp(matchPattern);
                    if (regex.test(reminder.content)) {
                        await reminderAgentManager.cancelReminder((reminder as ReminderRequestWithId).id);
                        console.info(`Removed reminder for subscription ${subscription.name}`);
                        break;
                    }
                }
            }
        }
        catch (error) {
            console.error('Remove reminder error:', error);
        }
    }
    /**
     * 为所有活跃订阅创建提醒
     * 先取消所有已有提醒，再重新创建
     */
    async createAllReminders(subscriptions: Subscription[]): Promise<void> {
        // 先取消所有已有提醒
        try {
            const allReminders = await reminderAgentManager.getValidReminders();
            for (const reminder of allReminders) {
                await reminderAgentManager.cancelReminder((reminder as ReminderRequestWithId).id);
            }
        }
        catch (e) {
            console.error('Cancel existing reminders error:', e);
        }
        // 重新创建
        for (const subscription of subscriptions) {
            if (subscription.isActive) {
                await this.createReminder(subscription);
            }
        }
    }
    /**
     * 移除所有提醒
     */
    async removeAllReminders(): Promise<void> {
        try {
            const allReminders = await reminderAgentManager.getValidReminders();
            for (const reminder of allReminders) {
                await reminderAgentManager.cancelReminder((reminder as ReminderRequestWithId).id);
            }
            console.info('Removed all reminders');
        }
        catch (error) {
            console.error('Remove all reminders error:', error);
        }
    }
    /**
     * 更新订阅的提醒
     */
    async updateReminder(subscription: Subscription): Promise<void> {
        // 先移除旧的提醒（如果存在）
        await this.removeReminder(subscription);
        // 再创建新的提醒
        await this.createReminder(subscription);
    }
    /**
     * 取消所有已有提醒
     */
    async cancelAllReminders(): Promise<void> {
        try {
            const allReminders = await reminderAgentManager.getValidReminders();
            for (const reminder of allReminders) {
                await reminderAgentManager.cancelReminder((reminder as ReminderRequestWithId).id);
            }
        }
        catch (error) {
            console.error('Cancel all reminders error:', error);
        }
    }
}
