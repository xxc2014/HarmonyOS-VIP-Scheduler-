import UIAbility from "@ohos:app.ability.UIAbility";
import type Want from "@ohos:app.ability.Want";
import type AbilityConstant from "@ohos:app.ability.AbilityConstant";
import hilog from "@ohos:hilog";
import type window from "@ohos:window";
import { StorageService } from "@normalized:N&&&entry/src/main/ets/service/StorageService&";
import { ReminderService } from "@normalized:N&&&entry/src/main/ets/service/ReminderService&";
const TAG = 'EntryAbility';
export default class EntryAbility extends UIAbility {
    onCreate(want: Want, launchParam: AbilityConstant.LaunchParam) {
        hilog.info(0x0000, TAG, '%{public}s', 'Ability onCreate');
        // 初始化存储服务 - 正确处理Promise
        StorageService.getInstance().init(this.context)
            .then(() => {
            hilog.info(0x0000, TAG, '%{public}s', 'StorageService initialized');
        })
            .catch((error: Error) => {
            hilog.error(0x0000, TAG, '%{public}s', 'StorageService init error: ' + JSON.stringify(error));
        });
        // 注意：由于init是async且有防重入保护，后续调用isInitialized()会立即返回true
        // 初始化提醒服务
        ReminderService.getInstance();
    }
    onDestroy() {
        hilog.info(0x0000, TAG, '%{public}s', 'Ability onDestroy');
    }
    onWindowStageCreate(windowStage: window.WindowStage) {
        // 加载主页面
        hilog.info(0x0000, TAG, '%{public}s', 'Ability onWindowStageCreate');
        windowStage.loadContent('pages/Index', (err, data) => {
            if (err.code) {
                hilog.error(0x0000, TAG, 'Failed to load the content. Cause: %{public}s', JSON.stringify(err) ?? '');
                return;
            }
            hilog.info(0x0000, TAG, 'Succeeded in loading the content. Data: %{public}s', JSON.stringify(data) ?? '');
        });
    }
    onWindowStageDestroy() {
        hilog.info(0x0000, TAG, '%{public}s', 'Ability onWindowStageDestroy');
    }
    onForeground() {
        hilog.info(0x0000, TAG, '%{public}s', 'Ability onForeground');
    }
    onBackground() {
        hilog.info(0x0000, TAG, '%{public}s', 'Ability onBackground');
    }
}
