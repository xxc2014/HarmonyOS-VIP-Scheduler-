if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface TabBarItem_Params {
    title?: string;
    emoji?: string;
    selected?: boolean;
    onTabClick?: () => void;
}
/**
 * 应用常量
 */
export class Constants {
    // 默认提前提醒天数
    static readonly DEFAULT_REMIND_DAYS = 3;
    // 提醒天数选项
    static readonly REMIND_DAYS_OPTIONS: number[] = [1, 2, 3, 5, 7, 14, 30];
    // 日期格式化
    static readonly DATE_FORMAT: string = 'YYYY-MM-DD';
    // 金额格式化
    static readonly AMOUNT_DECIMAL_PLACES: number = 2;
    // Tab索引
    static readonly TAB_INDEX_SUBSCRIPTION: number = 0;
    static readonly TAB_INDEX_CALENDAR: number = 1;
    static readonly TAB_INDEX_STATS: number = 2;
    // 动画时长
    static readonly ANIMATION_DURATION: number = 300;
}
/**
 * 颜色常量
 */
export class Colors {
    static readonly PRIMARY: string = '#1890FF';
    static readonly BACKGROUND: string = '#F5F5F5';
    static readonly CARD_BACKGROUND: string = '#FFFFFF';
    static readonly TEXT_PRIMARY: string = '#333333';
    static readonly TEXT_SECONDARY: string = '#666666';
    static readonly TEXT_HINT: string = '#999999';
    static readonly BORDER: string = '#E5E5E5';
    static readonly DANGER: string = '#FF4D4F';
    static readonly SUCCESS: string = '#52C41A';
    static readonly WARNING: string = '#FAAD14';
    // 分类颜色
    static readonly VIDEO: string = '#FF6B6B';
    static readonly MUSIC: string = '#4ECDC4';
    static readonly TOOL: string = '#45B7D1';
    static readonly CLOUD: string = '#96CEB4';
    static readonly OTHER: string = '#DDA0DD';
    // 状态颜色
    static readonly DUE_TODAY: string = '#FF4D4F';
    static readonly DUE_SOON: string = '#FAAD14';
    static readonly DUE_NORMAL: string = '#52C41A';
}
/**
 * 尺寸常量
 */
export class Sizes {
    static readonly CARD_PADDING: number = 16;
    static readonly CARD_MARGIN: number = 12;
    static readonly CARD_RADIUS: number = 12;
    static readonly ICON_SIZE: number = 24;
    static readonly BIG_ICON_SIZE: number = 48;
    static readonly BUTTON_HEIGHT: number = 44;
    static readonly INPUT_HEIGHT: number = 44;
    static readonly TAB_HEIGHT: number = 56;
}
/**
 * 字体大小常量
 */
export class FontSizes {
    static readonly SMALL: number = 12;
    static readonly NORMAL: number = 14;
    static readonly MEDIUM: number = 16;
    static readonly LARGE: number = 18;
    static readonly XLARGE: number = 20;
    static readonly XXLARGE: number = 24;
}
export class TabBarItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.title = '';
        this.emoji = '';
        this.selected = false;
        this.onTabClick = () => { };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: TabBarItem_Params) {
        if (params.title !== undefined) {
            this.title = params.title;
        }
        if (params.emoji !== undefined) {
            this.emoji = params.emoji;
        }
        if (params.selected !== undefined) {
            this.selected = params.selected;
        }
        if (params.onTabClick !== undefined) {
            this.onTabClick = params.onTabClick;
        }
    }
    updateStateVars(params: TabBarItem_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private title: string;
    private emoji: string;
    private selected: boolean;
    private onTabClick: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/common/Constants.ets(93:5)", "entry");
            Column.width(64);
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
            Column.onClick(this.onTabClick);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.emoji);
            Text.debugLine("entry/src/main/ets/common/Constants.ets(94:7)", "entry");
            Text.fontSize(24);
            Text.fontWeight(this.selected ? FontWeight.Bold : FontWeight.Normal);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.title);
            Text.debugLine("entry/src/main/ets/common/Constants.ets(98:7)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(this.selected ? Colors.PRIMARY : Colors.TEXT_HINT);
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
