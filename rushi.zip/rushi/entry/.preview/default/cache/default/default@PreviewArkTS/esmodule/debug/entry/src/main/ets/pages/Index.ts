if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    subscriptions?: Subscription[];
    currentTabIndex?: number;
    isLoading?: boolean;
    subscriptionService?: SubscriptionService;
    reminderService?: ReminderService;
    addDialogController?: CustomDialogController | null;
}
import type { Subscription, CreateSubscriptionRequest } from '../model/Subscription';
import { SubscriptionService } from "@normalized:N&&&entry/src/main/ets/service/SubscriptionService&";
import { ReminderService } from "@normalized:N&&&entry/src/main/ets/service/ReminderService&";
import { StorageService } from "@normalized:N&&&entry/src/main/ets/service/StorageService&";
import { SubscriptionList } from "@normalized:N&&&entry/src/main/ets/view/SubscriptionList&";
import { CalendarView } from "@normalized:N&&&entry/src/main/ets/view/CalendarView&";
import { StatsView } from "@normalized:N&&&entry/src/main/ets/view/StatsView&";
import { AddSubscriptionDialog } from "@normalized:N&&&entry/src/main/ets/view/AddSubscriptionDialog&";
import { Colors, FontSizes, Constants, TabBarItem } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
import promptAction from "@ohos:promptAction";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__subscriptions = new ObservedPropertyObjectPU([], this, "subscriptions");
        this.__currentTabIndex = new ObservedPropertySimplePU(0, this, "currentTabIndex");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.subscriptionService = SubscriptionService.getInstance();
        this.reminderService = ReminderService.getInstance();
        this.addDialogController = null;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.subscriptions !== undefined) {
            this.subscriptions = params.subscriptions;
        }
        if (params.currentTabIndex !== undefined) {
            this.currentTabIndex = params.currentTabIndex;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.subscriptionService !== undefined) {
            this.subscriptionService = params.subscriptionService;
        }
        if (params.reminderService !== undefined) {
            this.reminderService = params.reminderService;
        }
        if (params.addDialogController !== undefined) {
            this.addDialogController = params.addDialogController;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__subscriptions.purgeDependencyOnElmtId(rmElmtId);
        this.__currentTabIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__subscriptions.aboutToBeDeleted();
        this.__currentTabIndex.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __subscriptions: ObservedPropertyObjectPU<Subscription[]>;
    get subscriptions() {
        return this.__subscriptions.get();
    }
    set subscriptions(newValue: Subscription[]) {
        this.__subscriptions.set(newValue);
    }
    private __currentTabIndex: ObservedPropertySimplePU<number>;
    get currentTabIndex() {
        return this.__currentTabIndex.get();
    }
    set currentTabIndex(newValue: number) {
        this.__currentTabIndex.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private subscriptionService: SubscriptionService;
    private reminderService: ReminderService;
    private addDialogController: CustomDialogController | null;
    async aboutToAppear() {
        try {
            const storage = StorageService.getInstance();
            if (!storage.isInitialized()) {
                await storage.init(getContext(this));
            }
            await this.loadSubscriptions();
        }
        catch (error) {
            console.error('Init error:', error);
            this.isLoading = false;
        }
    }
    async loadSubscriptions() {
        try {
            const subs = await this.subscriptionService.loadAll();
            this.subscriptions = subs;
            await this.reminderService.createAllReminders(subs);
        }
        catch (error) {
            console.error('Load subscriptions error:', error);
        }
        finally {
            this.isLoading = false;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(48:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Colors.BACKGROUND);
        }, Column);
        this.TitleBar.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.LoadingView.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.ContentArea.bind(this)();
                });
            }
        }, If);
        If.pop();
        this.TabBar.bind(this)();
        Column.pop();
    }
    TitleBar(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(66:5)", "entry");
            Row.width('100%');
            Row.height(56);
            Row.padding({ left: 20, right: 16 });
            Row.backgroundColor(Colors.CARD_BACKGROUND);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.getTabTitle());
            Text.debugLine("entry/src/main/ets/pages/Index.ets(67:7)", "entry");
            Text.fontSize(FontSizes.XXLARGE);
            Text.fontColor(Colors.TEXT_PRIMARY);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(72:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.currentTabIndex === Constants.TAB_INDEX_SUBSCRIPTION) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithChild();
                        Button.debugLine("entry/src/main/ets/pages/Index.ets(75:9)", "entry");
                        Button.width(40);
                        Button.height(40);
                        Button.backgroundColor(Colors.PRIMARY + '15');
                        Button.borderRadius(20);
                        Button.onClick(() => {
                            this.showAddDialog();
                        });
                    }, Button);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('+');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(76:11)", "entry");
                        Text.fontSize(24);
                        Text.fontColor(Colors.PRIMARY);
                    }, Text);
                    Text.pop();
                    Button.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Row.pop();
    }
    LoadingView(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(97:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            LoadingProgress.create();
            LoadingProgress.debugLine("entry/src/main/ets/pages/Index.ets(98:7)", "entry");
            LoadingProgress.width(48);
            LoadingProgress.height(48);
            LoadingProgress.color(Colors.PRIMARY);
        }, LoadingProgress);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('加载中...');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(102:7)", "entry");
            Text.fontSize(FontSizes.NORMAL);
            Text.fontColor(Colors.TEXT_HINT);
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        Column.pop();
    }
    ContentArea(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(114:5)", "entry");
            Stack.width('100%');
            Stack.layoutWeight(1);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.currentTabIndex === Constants.TAB_INDEX_SUBSCRIPTION) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(116:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                    }, Column);
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new SubscriptionList(this, {
                                    subscriptions: this.__subscriptions,
                                    onEdit: (subscription) => {
                                        this.showEditDialog(subscription);
                                    },
                                    onDelete: async (id) => {
                                        await this.deleteSubscription(id);
                                    }
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 117, col: 11 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        subscriptions: this.subscriptions,
                                        onEdit: (subscription) => {
                                            this.showEditDialog(subscription);
                                        },
                                        onDelete: async (id) => {
                                            await this.deleteSubscription(id);
                                        }
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "SubscriptionList" });
                    }
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.currentTabIndex === Constants.TAB_INDEX_CALENDAR) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(132:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                    }, Column);
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new CalendarView(this, {
                                    subscriptions: this.__subscriptions
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 133, col: 11 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        subscriptions: this.subscriptions
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "CalendarView" });
                    }
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.currentTabIndex === Constants.TAB_INDEX_STATS) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(142:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                    }, Column);
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new StatsView(this, {
                                    subscriptions: this.__subscriptions
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 143, col: 11 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        subscriptions: this.subscriptions
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "StatsView" });
                    }
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    TabBar(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(157:5)", "entry");
            Row.width('100%');
            Row.height(60);
            Row.backgroundColor(Colors.CARD_BACKGROUND);
            Row.justifyContent(FlexAlign.SpaceAround);
            Row.alignItems(VerticalAlign.Center);
            Row.border({
                width: { top: 0.5 },
                color: Colors.BORDER
            });
        }, Row);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new TabBarItem(this, {
                        title: '订阅',
                        emoji: '📋',
                        selected: this.currentTabIndex === Constants.TAB_INDEX_SUBSCRIPTION,
                        onTabClick: () => {
                            this.currentTabIndex = Constants.TAB_INDEX_SUBSCRIPTION;
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 158, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '订阅',
                            emoji: '📋',
                            selected: this.currentTabIndex === Constants.TAB_INDEX_SUBSCRIPTION,
                            onTabClick: () => {
                                this.currentTabIndex = Constants.TAB_INDEX_SUBSCRIPTION;
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "TabBarItem" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new TabBarItem(this, {
                        title: '日历',
                        emoji: '📅',
                        selected: this.currentTabIndex === Constants.TAB_INDEX_CALENDAR,
                        onTabClick: () => {
                            this.currentTabIndex = Constants.TAB_INDEX_CALENDAR;
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 167, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '日历',
                            emoji: '📅',
                            selected: this.currentTabIndex === Constants.TAB_INDEX_CALENDAR,
                            onTabClick: () => {
                                this.currentTabIndex = Constants.TAB_INDEX_CALENDAR;
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "TabBarItem" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new TabBarItem(this, {
                        title: '统计',
                        emoji: '📊',
                        selected: this.currentTabIndex === Constants.TAB_INDEX_STATS,
                        onTabClick: () => {
                            this.currentTabIndex = Constants.TAB_INDEX_STATS;
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 176, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '统计',
                            emoji: '📊',
                            selected: this.currentTabIndex === Constants.TAB_INDEX_STATS,
                            onTabClick: () => {
                                this.currentTabIndex = Constants.TAB_INDEX_STATS;
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "TabBarItem" });
        }
        Row.pop();
    }
    private getTabTitle(): string {
        switch (this.currentTabIndex) {
            case Constants.TAB_INDEX_SUBSCRIPTION:
                return '我的订阅';
            case Constants.TAB_INDEX_CALENDAR:
                return '扣费日历';
            case Constants.TAB_INDEX_STATS:
                return '费用统计';
            default:
                return '续费管家';
        }
    }
    private showAddDialog(): void {
        this.addDialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new AddSubscriptionDialog(this, {
                    subscription: null,
                    onSave: async (request) => {
                        await this.addSubscription(request);
                    }
                }, undefined, -1, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 211, col: 16 });
                jsDialog.setController(this.addDialogController);
                ViewPU.create(jsDialog);
                let paramsLambda = () => {
                    return {
                        subscription: null,
                        onSave: async (request) => {
                            await this.addSubscription(request);
                        }
                    };
                };
                jsDialog.paramsGenerator_ = paramsLambda;
            },
            customStyle: true,
            alignment: DialogAlignment.Bottom
        }, this);
        this.addDialogController.open();
    }
    private showEditDialog(subscription: Subscription): void {
        this.addDialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new AddSubscriptionDialog(this, {
                    subscription: subscription,
                    onUpdate: async (id, request) => {
                        await this.updateSubscription(id, request);
                    },
                    onDelete: async (id) => {
                        await this.deleteSubscription(id);
                    }
                }, undefined, -1, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 225, col: 16 });
                jsDialog.setController(this.addDialogController);
                ViewPU.create(jsDialog);
                let paramsLambda = () => {
                    return {
                        subscription: subscription,
                        onUpdate: async (id, request) => {
                            await this.updateSubscription(id, request);
                        },
                        onDelete: async (id) => {
                            await this.deleteSubscription(id);
                        }
                    };
                };
                jsDialog.paramsGenerator_ = paramsLambda;
            },
            customStyle: true,
            alignment: DialogAlignment.Bottom
        }, this);
        this.addDialogController.open();
    }
    private async addSubscription(request: CreateSubscriptionRequest): Promise<void> {
        try {
            const newSubscription = await this.subscriptionService.add(request);
            this.subscriptions = [...this.subscriptions, newSubscription];
            await this.reminderService.createReminder(newSubscription);
            promptAction.showToast({ message: '添加成功' });
        }
        catch (error) {
            console.error('Add subscription error:', error);
            promptAction.showToast({ message: '添加失败' });
        }
    }
    private async updateSubscription(id: string, request: CreateSubscriptionRequest): Promise<void> {
        try {
            const updated = await this.subscriptionService.update(id, request);
            if (updated) {
                const index = this.subscriptions.findIndex(s => s.id === id);
                if (index !== -1) {
                    this.subscriptions[index] = updated;
                    this.subscriptions = [...this.subscriptions];
                }
                await this.reminderService.updateReminder(updated);
                promptAction.showToast({ message: '更新成功' });
            }
        }
        catch (error) {
            console.error('Update subscription error:', error);
            promptAction.showToast({ message: '更新失败' });
        }
    }
    private async deleteSubscription(id: string): Promise<void> {
        try {
            const subscription = this.subscriptions.find(s => s.id === id);
            if (subscription) {
                await this.reminderService.removeReminder(subscription);
            }
            await this.subscriptionService.delete(id);
            this.subscriptions = this.subscriptions.filter(s => s.id !== id);
            promptAction.showToast({ message: '删除成功' });
        }
        catch (error) {
            console.error('Delete subscription error:', error);
            promptAction.showToast({ message: '删除失败' });
        }
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.rushi", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
