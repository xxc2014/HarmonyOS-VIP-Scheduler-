if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface CalendarView_Params {
    subscriptions?: Subscription[];
    currentYear?: number;
    currentMonth?: number;
    selectedDate?: string;
    selectedDateSubscriptions?: Subscription[];
    weekDayNames?: string[];
}
import { getCategoryConfig } from "@normalized:N&&&entry/src/main/ets/model/Subscription&";
import type { Subscription } from "@normalized:N&&&entry/src/main/ets/model/Subscription&";
import { Colors, FontSizes } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
export class CalendarView extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__subscriptions = new SynchedPropertyObjectTwoWayPU(params.subscriptions, this, "subscriptions");
        this.__currentYear = new ObservedPropertySimplePU(new Date().getFullYear(), this, "currentYear");
        this.__currentMonth = new ObservedPropertySimplePU(new Date().getMonth() + 1, this, "currentMonth");
        this.__selectedDate = new ObservedPropertySimplePU('', this, "selectedDate");
        this.__selectedDateSubscriptions = new ObservedPropertyObjectPU([], this, "selectedDateSubscriptions");
        this.weekDayNames = ['日', '一', '二', '三', '四', '五', '六'];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CalendarView_Params) {
        if (params.currentYear !== undefined) {
            this.currentYear = params.currentYear;
        }
        if (params.currentMonth !== undefined) {
            this.currentMonth = params.currentMonth;
        }
        if (params.selectedDate !== undefined) {
            this.selectedDate = params.selectedDate;
        }
        if (params.selectedDateSubscriptions !== undefined) {
            this.selectedDateSubscriptions = params.selectedDateSubscriptions;
        }
        if (params.weekDayNames !== undefined) {
            this.weekDayNames = params.weekDayNames;
        }
    }
    updateStateVars(params: CalendarView_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__subscriptions.purgeDependencyOnElmtId(rmElmtId);
        this.__currentYear.purgeDependencyOnElmtId(rmElmtId);
        this.__currentMonth.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedDate.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedDateSubscriptions.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__subscriptions.aboutToBeDeleted();
        this.__currentYear.aboutToBeDeleted();
        this.__currentMonth.aboutToBeDeleted();
        this.__selectedDate.aboutToBeDeleted();
        this.__selectedDateSubscriptions.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __subscriptions: SynchedPropertySimpleOneWayPU<Subscription[]>;
    get subscriptions() {
        return this.__subscriptions.get();
    }
    set subscriptions(newValue: Subscription[]) {
        this.__subscriptions.set(newValue);
    }
    private __currentYear: ObservedPropertySimplePU<number>;
    get currentYear() {
        return this.__currentYear.get();
    }
    set currentYear(newValue: number) {
        this.__currentYear.set(newValue);
    }
    private __currentMonth: ObservedPropertySimplePU<number>;
    get currentMonth() {
        return this.__currentMonth.get();
    }
    set currentMonth(newValue: number) {
        this.__currentMonth.set(newValue);
    }
    private __selectedDate: ObservedPropertySimplePU<string>;
    get selectedDate() {
        return this.__selectedDate.get();
    }
    set selectedDate(newValue: string) {
        this.__selectedDate.set(newValue);
    }
    private __selectedDateSubscriptions: ObservedPropertyObjectPU<Subscription[]>;
    get selectedDateSubscriptions() {
        return this.__selectedDateSubscriptions.get();
    }
    set selectedDateSubscriptions(newValue: Subscription[]) {
        this.__selectedDateSubscriptions.set(newValue);
    }
    private weekDayNames: string[];
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/CalendarView.ets(17:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Colors.BACKGROUND);
        }, Column);
        // 月份切换头部
        this.MonthHeader.bind(this)();
        // 日历网格
        this.CalendarGrid.bind(this)();
        // 选中日期的订阅列表
        this.SelectedDateSubscriptions.bind(this)();
        Column.pop();
    }
    MonthHeader(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/CalendarView.ets(34:5)", "entry");
            Row.width('100%');
            Row.padding({ left: 16, right: 16, top: 12, bottom: 12 });
            Row.backgroundColor(Colors.CARD_BACKGROUND);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/view/CalendarView.ets(35:7)", "entry");
            Button.width(44);
            Button.height(44);
            Button.backgroundColor(Color.Transparent);
            Button.onClick(() => {
                this.prevMonth();
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('<');
            Text.debugLine("entry/src/main/ets/view/CalendarView.ets(36:9)", "entry");
            Text.fontSize(FontSizes.XLARGE);
            Text.fontColor(Colors.PRIMARY);
        }, Text);
        Text.pop();
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.currentYear}年${this.currentMonth}月`);
            Text.debugLine("entry/src/main/ets/view/CalendarView.ets(47:7)", "entry");
            Text.fontSize(FontSizes.LARGE);
            Text.fontColor(Colors.TEXT_PRIMARY);
            Text.fontWeight(FontWeight.Medium);
            Text.layoutWeight(1);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/view/CalendarView.ets(54:7)", "entry");
            Button.width(44);
            Button.height(44);
            Button.backgroundColor(Color.Transparent);
            Button.onClick(() => {
                this.nextMonth();
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/view/CalendarView.ets(55:9)", "entry");
            Text.fontSize(FontSizes.XLARGE);
            Text.fontColor(Colors.PRIMARY);
        }, Text);
        Text.pop();
        Button.pop();
        Row.pop();
    }
    CalendarGrid(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/CalendarView.ets(73:5)", "entry");
            Column.padding({ top: 8 });
            Column.backgroundColor(Colors.CARD_BACKGROUND);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 星期标题行
            Row.create();
            Row.debugLine("entry/src/main/ets/view/CalendarView.ets(75:7)", "entry");
            // 星期标题行
            Row.height(32);
            // 星期标题行
            Row.padding({ left: 8, right: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const day = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(day);
                    Text.debugLine("entry/src/main/ets/view/CalendarView.ets(77:11)", "entry");
                    Text.fontSize(FontSizes.SMALL);
                    Text.fontColor(Colors.TEXT_SECONDARY);
                    Text.width('14.28%');
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, this.weekDayNames, forEachItemGenFunction, (day: string, index: number) => day + '_' + index.toString(), true, true);
        }, ForEach);
        ForEach.pop();
        // 星期标题行
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 日期网格
            Grid.create();
            Grid.debugLine("entry/src/main/ets/view/CalendarView.ets(88:7)", "entry");
            // 日期网格
            Grid.columnsTemplate('1fr 1fr 1fr 1fr 1fr 1fr 1fr');
            // 日期网格
            Grid.columnsGap(0);
            // 日期网格
            Grid.rowsGap(0);
            // 日期网格
            Grid.padding({ left: 8, right: 8 });
        }, Grid);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const day = _item;
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.debugLine("entry/src/main/ets/view/CalendarView.ets(90:11)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.DayCell.bind(this)(day);
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
            };
            this.forEachUpdateFunction(elmtId, this.getCalendarDays(), forEachItemGenFunction, (day: CalendarDay, index: number) => day.day.toString() + '_' + index, false, true);
        }, ForEach);
        ForEach.pop();
        // 日期网格
        Grid.pop();
        Column.pop();
    }
    DayCell(day: CalendarDay, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/CalendarView.ets(106:5)", "entry");
            Column.width('100%');
            Column.height(50);
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Center);
            Column.backgroundColor(day.isSelected ? Colors.PRIMARY + '20' : Color.Transparent);
            Column.borderRadius(8);
            Column.onClick(() => {
                if (day.day > 0) {
                    this.selectDate(day);
                }
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/view/CalendarView.ets(107:7)", "entry");
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 今天圆圈（放底层）
            if (day.isToday) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Circle.create();
                        Circle.debugLine("entry/src/main/ets/view/CalendarView.ets(110:11)", "entry");
                        Circle.width(32);
                        Circle.height(32);
                        Circle.fill(Colors.PRIMARY);
                    }, Circle);
                });
            }
            // 日期数字（放上层）
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 日期数字（放上层）
            Text.create(day.day > 0 ? day.day.toString() : '');
            Text.debugLine("entry/src/main/ets/view/CalendarView.ets(117:9)", "entry");
            // 日期数字（放上层）
            Text.fontSize(FontSizes.NORMAL);
            // 日期数字（放上层）
            Text.fontColor(day.isToday ? '#FFFFFF' : (day.isSelected ? Colors.PRIMARY : Colors.TEXT_PRIMARY));
            // 日期数字（放上层）
            Text.width(32);
            // 日期数字（放上层）
            Text.height(32);
            // 日期数字（放上层）
            Text.textAlign(TextAlign.Center);
        }, Text);
        // 日期数字（放上层）
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 有订阅标记点
            if (day.hasSubscription) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/view/CalendarView.ets(126:11)", "entry");
                        Row.position({ y: 34 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const emoji = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(emoji);
                                Text.debugLine("entry/src/main/ets/view/CalendarView.ets(128:15)", "entry");
                                Text.fontSize(8);
                            }, Text);
                            Text.pop();
                        };
                        this.forEachUpdateFunction(elmtId, day.subscriptionEmojis.slice(0, 3), forEachItemGenFunction, (emoji: string, index: number) => emoji + '_' + index.toString(), true, true);
                    }, ForEach);
                    ForEach.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
        Column.pop();
    }
    SelectedDateSubscriptions(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/CalendarView.ets(151:5)", "entry");
            Column.width('100%');
            Column.layoutWeight(1);
            Column.backgroundColor(Colors.CARD_BACKGROUND);
            Column.margin({ top: 8 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 标题
            if (this.selectedDate) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatSelectedDate(this.selectedDate));
                        Text.debugLine("entry/src/main/ets/view/CalendarView.ets(154:9)", "entry");
                        Text.fontSize(FontSizes.MEDIUM);
                        Text.fontColor(Colors.TEXT_PRIMARY);
                        Text.fontWeight(FontWeight.Medium);
                        Text.width('100%');
                        Text.padding({ left: 16, right: 16, top: 16, bottom: 8 });
                    }, Text);
                    Text.pop();
                });
            }
            // 订阅列表
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 订阅列表
            if (this.selectedDateSubscriptions.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create();
                        List.debugLine("entry/src/main/ets/view/CalendarView.ets(164:9)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.padding({ left: 16, right: 16 });
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const subscription = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/view/CalendarView.ets(166:13)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.SubscriptionItem.bind(this)(subscription);
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.selectedDateSubscriptions, forEachItemGenFunction, (subscription: Subscription) => subscription.id, false, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.selectedDate ? '当日无扣费' : '请选择一个日期');
                        Text.debugLine("entry/src/main/ets/view/CalendarView.ets(175:9)", "entry");
                        Text.fontSize(FontSizes.NORMAL);
                        Text.fontColor(Colors.TEXT_HINT);
                        Text.width('100%');
                        Text.textAlign(TextAlign.Center);
                        Text.padding(24);
                    }, Text);
                    Text.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    SubscriptionItem(subscription: Subscription, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/CalendarView.ets(191:5)", "entry");
            Row.width('100%');
            Row.padding({ top: 12, bottom: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(getCategoryConfig(subscription.category).emoji);
            Text.debugLine("entry/src/main/ets/view/CalendarView.ets(192:7)", "entry");
            Text.fontSize(24);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/CalendarView.ets(195:7)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(subscription.name);
            Text.debugLine("entry/src/main/ets/view/CalendarView.ets(196:9)", "entry");
            Text.fontSize(FontSizes.NORMAL);
            Text.fontColor(Colors.TEXT_PRIMARY);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${subscription.amount.toFixed(2)} 元`);
            Text.debugLine("entry/src/main/ets/view/CalendarView.ets(201:9)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(Colors.TEXT_SECONDARY);
            Text.margin({ top: 2 });
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
    }
    // 获取日历数据
    private getCalendarDays(): CalendarDay[] {
        const days: CalendarDay[] = [];
        const today = new Date();
        const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
        // 月的第一天是星期几
        const firstDay = new Date(this.currentYear, this.currentMonth - 1, 1);
        const startWeekDay = firstDay.getDay();
        // 月的最后一天
        const lastDay = new Date(this.currentYear, this.currentMonth, 0).getDate();
        // 添加上月的空白日期
        for (let i = 0; i < startWeekDay; i++) {
            days.push({
                day: -1,
                isToday: false,
                isSelected: false,
                hasSubscription: false,
                subscriptionEmojis: []
            });
        }
        // 添加本月的日期
        for (let d = 1; d <= lastDay; d++) {
            const dateStr = `${this.currentYear}-${String(this.currentMonth).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
            const daySubscriptions = this.subscriptions.filter(s => s.nextDate === dateStr);
            days.push({
                day: d,
                isToday: dateStr === todayStr,
                isSelected: dateStr === this.selectedDate,
                hasSubscription: daySubscriptions.length > 0,
                subscriptionEmojis: daySubscriptions.map(s => getCategoryConfig(s.category).emoji)
            });
        }
        return days;
    }
    // 选择日期
    private selectDate(day: CalendarDay): void {
        if (day.day < 0)
            return;
        const dateStr = `${this.currentYear}-${String(this.currentMonth).padStart(2, '0')}-${String(day.day).padStart(2, '0')}`;
        this.selectedDate = dateStr;
        this.selectedDateSubscriptions = this.subscriptions.filter(s => s.nextDate === dateStr);
    }
    // 上一个月
    private prevMonth(): void {
        if (this.currentMonth === 1) {
            this.currentMonth = 12;
            this.currentYear--;
        }
        else {
            this.currentMonth--;
        }
        this.selectedDate = '';
        this.selectedDateSubscriptions = [];
    }
    // 下一个月
    private nextMonth(): void {
        if (this.currentMonth === 12) {
            this.currentMonth = 1;
            this.currentYear++;
        }
        else {
            this.currentMonth++;
        }
        this.selectedDate = '';
        this.selectedDateSubscriptions = [];
    }
    // 格式化选中日期
    private formatSelectedDate(dateStr: string): string {
        const parts = dateStr.split('-');
        return `${parseInt(parts[1])}月${parseInt(parts[2])}日`;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
/**
 * 日历日期数据结构
 */
interface CalendarDay {
    day: number;
    isToday: boolean;
    isSelected: boolean;
    hasSubscription: boolean;
    subscriptionEmojis: string[];
}
