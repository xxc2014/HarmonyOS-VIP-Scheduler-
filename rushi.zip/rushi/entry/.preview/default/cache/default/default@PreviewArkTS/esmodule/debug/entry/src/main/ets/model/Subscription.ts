/**
 * 订阅数据结构
 */
export interface Subscription {
    id: string; // UUID
    name: string; // 订阅名称
    amount: number; // 金额
    cycleType: CycleType; // 周期类型
    firstDate: string; // 首次扣费日 YYYY-MM-DD
    nextDate: string; // 下次扣费日 YYYY-MM-DD（自动计算）
    category: Category; // 分类
    remindDays: number; // 提前提醒天数
    isActive: boolean; // 是否启用
}
/**
 * 周期类型
 */
export type CycleType = 'monthly' | 'quarterly' | 'yearly';
/**
 * 订阅分类
 */
export type Category = 'video' | 'music' | 'tool' | 'cloud' | 'other';
/**
 * 分类配置
 */
export interface CategoryConfig {
    name: Category;
    label: string;
    emoji: string;
    color: string;
}
/**
 * 周期配置
 */
export interface CycleConfig {
    type: CycleType;
    label: string;
    months: number;
}
/**
 * 创建订阅请求
 */
export interface CreateSubscriptionRequest {
    name: string;
    amount: number;
    cycleType: CycleType;
    firstDate: string;
    category: Category;
    remindDays: number;
    isActive: boolean;
}
/**
 * 日期工具类
 */
export class DateUtils {
    /**
     * 验证日期字符串是否有效
     */
    static isValidDate(dateStr: string): boolean {
        if (!dateStr || typeof dateStr !== 'string') {
            return false;
        }
        const regex = /^\d{4}-\d{2}-\d{2}$/;
        if (!regex.test(dateStr)) {
            return false;
        }
        const date = DateUtils.parseDate(dateStr);
        return !isNaN(date.getTime());
    }
    /**
     * 获取指定日期的月份最后一天
     */
    static getMonthLastDay(year: number, month: number): number {
        // 月份从0开始，所以要减1
        // 设置为下个月的第一天，然后减1天
        const nextMonth = new Date(year, month, 1);
        nextMonth.setDate(nextMonth.getDate() - 1);
        return nextMonth.getDate();
    }
    /**
     * 解析日期字符串
     */
    static parseDate(dateStr: string): Date {
        const parts = dateStr.split('-');
        if (parts.length !== 3) {
            return new Date();
        }
        const year = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10) - 1;
        const day = parseInt(parts[2], 10);
        if (isNaN(year) || isNaN(month) || isNaN(day)) {
            return new Date();
        }
        return new Date(year, month, day);
    }
    /**
     * 格式化日期为字符串
     */
    static formatDate(date: Date): string {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    /**
     * 计算下次扣费日期
     */
    static calculateNextDate(firstDate: string, cycleType: CycleType): string {
        // 验证日期有效性
        if (!DateUtils.isValidDate(firstDate)) {
            console.error('Invalid date format:', firstDate);
            return DateUtils.formatDate(new Date()); // 返回今天作为默认值
        }
        const first = DateUtils.parseDate(firstDate);
        const now = new Date();
        now.setHours(0, 0, 0, 0);
        const originalDay = first.getDate();
        const addMonths = cycleType === 'monthly' ? 1 : cycleType === 'quarterly' ? 3 : 12;
        let year = first.getFullYear();
        let month = first.getMonth() + 1; // 1-based
        // 构造首次扣费日
        let lastDay = DateUtils.getMonthLastDay(year, month);
        let day = originalDay > lastDay ? lastDay : originalDay;
        let checkDate = DateUtils.parseDate(`${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`);
        // 如果首次扣费日已经在未来，直接返回
        if (checkDate > now) {
            return DateUtils.formatDate(checkDate);
        }
        // 循环加周期直到超过今天
        while (checkDate <= now) {
            month += addMonths;
            while (month > 12) {
                month -= 12;
                year++;
            }
            lastDay = DateUtils.getMonthLastDay(year, month);
            day = originalDay > lastDay ? lastDay : originalDay;
            checkDate = DateUtils.parseDate(`${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`);
        }
        return DateUtils.formatDate(checkDate);
    }
    /**
     * 计算两个日期之间的天数
     */
    static daysBetween(date1: string, date2: string): number {
        const d1 = DateUtils.parseDate(date1);
        const d2 = DateUtils.parseDate(date2);
        const diffTime = Math.abs(d2.getTime() - d1.getTime());
        return Math.floor(diffTime / (1000 * 60 * 60 * 24));
    }
    /**
     * 计算从今天到指定日期的天数
     */
    static daysFromNow(dateStr: string): number {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const target = DateUtils.parseDate(dateStr);
        target.setHours(0, 0, 0, 0);
        const diffTime = target.getTime() - today.getTime();
        return Math.floor(diffTime / (1000 * 60 * 60 * 24));
    }
    /**
     * 获取日期所在月份的第一天
     */
    static getMonthFirstDay(dateStr: string): string {
        const date = DateUtils.parseDate(dateStr);
        return DateUtils.formatDate(new Date(date.getFullYear(), date.getMonth(), 1));
    }
    /**
     * 获取日期所在月份的最后一天
     */
    static getMonthLastDayStr(dateStr: string): string {
        const date = DateUtils.parseDate(dateStr);
        const lastDay = DateUtils.getMonthLastDay(date.getFullYear(), date.getMonth() + 1);
        return DateUtils.formatDate(new Date(date.getFullYear(), date.getMonth(), lastDay));
    }
    /**
     * 生成UUID
     */
    static generateUUID(): string {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }
    /**
     * 获取年月的第一天
     */
    static getYearMonthFirstDay(year: number, month: number): string {
        return `${year}-${String(month).padStart(2, '0')}-01`;
    }
    /**
     * 获取年月的最后一天
     */
    static getYearMonthLastDay(year: number, month: number): string {
        const lastDay = DateUtils.getMonthLastDay(year, month);
        return `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
    }
}
/**
 * 分类配置列表
 */
export const CATEGORY_CONFIGS: CategoryConfig[] = [
    { name: 'video', label: '视频', emoji: '📺', color: '#FF6B6B' },
    { name: 'music', label: '音乐', emoji: '🎵', color: '#4ECDC4' },
    { name: 'tool', label: '工具', emoji: '🔧', color: '#45B7D1' },
    { name: 'cloud', label: '云盘', emoji: '☁️', color: '#96CEB4' },
    { name: 'other', label: '其他', emoji: '📦', color: '#DDA0DD' }
];
/**
 * 周期配置列表
 */
export const CYCLE_CONFIGS: CycleConfig[] = [
    { type: 'monthly', label: '每月', months: 1 },
    { type: 'quarterly', label: '每季度', months: 3 },
    { type: 'yearly', label: '每年', months: 12 }
];
/**
 * 获取分类配置
 */
export function getCategoryConfig(category: Category): CategoryConfig {
    const config = CATEGORY_CONFIGS.find(c => c.name === category);
    return config || CATEGORY_CONFIGS[4];
}
/**
 * 获取周期配置
 */
export function getCycleConfig(cycleType: CycleType): CycleConfig {
    const config = CYCLE_CONFIGS.find(c => c.type === cycleType);
    return config || CYCLE_CONFIGS[0];
}
