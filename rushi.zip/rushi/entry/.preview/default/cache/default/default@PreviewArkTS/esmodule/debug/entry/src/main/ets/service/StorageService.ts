import dataPreferences from "@ohos:data.preferences";
/**
 * 存储服务 - 管理应用数据持久化
 */
export class StorageService {
    private static instance: StorageService = new StorageService();
    private preferences: dataPreferences.Preferences | null = null;
    private readonly STORE_NAME = 'subscription_store';
    private readonly SUBSCRIPTIONS_KEY = 'subscriptions';
    private constructor() { }
    /**
     * 获取单例实例
     */
    static getInstance(): StorageService {
        return StorageService.instance;
    }
    /**
     * 检查是否已初始化
     */
    isInitialized(): boolean {
        return this.preferences !== null;
    }
    /**
     * 初始化存储服务
     */
    async init(context: Context): Promise<void> {
        if (this.preferences !== null) {
            return;
        }
        try {
            this.preferences = await dataPreferences.getPreferences(context, this.STORE_NAME);
        }
        catch (error) {
            console.error('StorageService init error:', error);
            throw new Error(String(error));
        }
    }
    /**
     * 保存订阅列表
     */
    async saveSubscriptions(subscriptions: string): Promise<void> {
        if (!this.preferences) {
            throw new Error('StorageService not initialized');
        }
        await this.preferences.put(this.SUBSCRIPTIONS_KEY, subscriptions);
        await this.preferences.flush();
    }
    /**
     * 获取订阅列表
     */
    async getSubscriptions(): Promise<string | null> {
        if (!this.preferences) {
            throw new Error('StorageService not initialized');
        }
        const result = await this.preferences.get(this.SUBSCRIPTIONS_KEY, null);
        if (typeof result === 'string') {
            return result;
        }
        return null;
    }
    /**
     * 清除所有数据
     */
    async clear(): Promise<void> {
        if (!this.preferences) {
            throw new Error('StorageService not initialized');
        }
        await this.preferences.clear();
        await this.preferences.flush();
    }
}
