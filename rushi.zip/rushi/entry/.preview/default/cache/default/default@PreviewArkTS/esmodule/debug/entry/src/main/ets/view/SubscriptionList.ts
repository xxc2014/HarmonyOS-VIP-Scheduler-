if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SubscriptionList_Params {
    subscriptions?: Subscription[];
    isLoading?: boolean;
    onRefresh?: () => void;
    onEdit?: (subscription: Subscription) => void;
    onDelete?: (id: string) => void;
}
import { getCategoryConfig, DateUtils } from "@normalized:N&&&entry/src/main/ets/model/Subscription&";
import type { Subscription } from "@normalized:N&&&entry/src/main/ets/model/Subscription&";
import { Colors, Sizes, FontSizes } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
import promptAction from "@ohos:promptAction";
export class SubscriptionList extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__subscriptions = new SynchedPropertyObjectTwoWayPU(params.subscriptions, this, "subscriptions");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.onRefresh = () => { };
        this.onEdit = () => { };
        this.onDelete = () => { };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SubscriptionList_Params) {
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.onRefresh !== undefined) {
            this.onRefresh = params.onRefresh;
        }
        if (params.onEdit !== undefined) {
            this.onEdit = params.onEdit;
        }
        if (params.onDelete !== undefined) {
            this.onDelete = params.onDelete;
        }
    }
    updateStateVars(params: SubscriptionList_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__subscriptions.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__subscriptions.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __subscriptions: SynchedPropertySimpleOneWayPU<Subscription[]>;
    get subscriptions() {
        return this.__subscriptions.get();
    }
    set subscriptions(newValue: Subscription[]) {
        this.__subscriptions.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private onRefresh: () => void;
    private onEdit: (subscription: Subscription) => void;
    private onDelete: (id: string) => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.subscriptions.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.EmptyView.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create();
                        List.debugLine("entry/src/main/ets/view/SubscriptionList.ets(20:7)", "entry");
                        List.width('100%');
                        List.height('100%');
                        List.layoutWeight(1);
                        List.listDirection(Axis.Vertical);
                        List.divider({ strokeWidth: 0.5, color: Colors.BORDER, startMargin: 68, endMargin: 16 });
                        List.padding({ left: 16, right: 16, top: 8, bottom: 8 });
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const subscription = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.swipeAction({
                                        end: {
                                            builder: () => {
                                                this.DeleteButton(subscription.id);
                                            },
                                            actionAreaDistance: 60
                                        }
                                    });
                                    ListItem.debugLine("entry/src/main/ets/view/SubscriptionList.ets(22:11)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.SubscriptionCard.bind(this)(subscription);
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.subscriptions, forEachItemGenFunction, (subscription: Subscription) => subscription.id, false, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
    }
    EmptyView(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/SubscriptionList.ets(46:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📋');
            Text.debugLine("entry/src/main/ets/view/SubscriptionList.ets(47:7)", "entry");
            Text.fontSize(48);
            Text.margin({ bottom: 16 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('暂无订阅');
            Text.debugLine("entry/src/main/ets/view/SubscriptionList.ets(50:7)", "entry");
            Text.fontSize(FontSizes.MEDIUM);
            Text.fontColor(Colors.TEXT_HINT);
            Text.margin({ bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('点击右上角添加');
            Text.debugLine("entry/src/main/ets/view/SubscriptionList.ets(54:7)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(Colors.TEXT_HINT);
        }, Text);
        Text.pop();
        Column.pop();
    }
    SubscriptionCard(subscription: Subscription, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/SubscriptionList.ets(66:5)", "entry");
            Row.width('100%');
            Row.padding(Sizes.CARD_PADDING);
            Row.backgroundColor(Colors.CARD_BACKGROUND);
            Row.borderRadius(Sizes.CARD_RADIUS);
            Row.onClick(() => {
                this.onEdit(subscription);
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 分类图标
            Text.create(getCategoryConfig(subscription.category).emoji);
            Text.debugLine("entry/src/main/ets/view/SubscriptionList.ets(68:7)", "entry");
            // 分类图标
            Text.fontSize(32);
            // 分类图标
            Text.width(48);
            // 分类图标
            Text.height(48);
            // 分类图标
            Text.backgroundColor(getCategoryConfig(subscription.category).color + '20');
            // 分类图标
            Text.borderRadius(12);
            // 分类图标
            Text.textAlign(TextAlign.Center);
            // 分类图标
            Text.flexShrink(0);
        }, Text);
        // 分类图标
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 订阅信息
            Column.create();
            Column.debugLine("entry/src/main/ets/view/SubscriptionList.ets(78:7)", "entry");
            // 订阅信息
            Column.layoutWeight(1);
            // 订阅信息
            Column.alignItems(HorizontalAlign.Start);
            // 订阅信息
            Column.margin({ left: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/SubscriptionList.ets(79:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(subscription.name);
            Text.debugLine("entry/src/main/ets/view/SubscriptionList.ets(80:11)", "entry");
            Text.fontSize(FontSizes.MEDIUM);
            Text.fontColor(Colors.TEXT_PRIMARY);
            Text.fontWeight(FontWeight.Medium);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!subscription.isActive) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('已暂停');
                        Text.debugLine("entry/src/main/ets/view/SubscriptionList.ets(88:13)", "entry");
                        Text.fontSize(FontSizes.SMALL);
                        Text.fontColor(Colors.TEXT_HINT);
                        Text.backgroundColor(Colors.BORDER);
                        Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                        Text.borderRadius(4);
                        Text.margin({ left: 8 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${getCategoryConfig(subscription.category).label} · ${subscription.amount.toFixed(2)} 元`);
            Text.debugLine("entry/src/main/ets/view/SubscriptionList.ets(98:9)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(Colors.TEXT_SECONDARY);
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        // 订阅信息
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 倒计时信息
            Column.create();
            Column.debugLine("entry/src/main/ets/view/SubscriptionList.ets(108:7)", "entry");
            // 倒计时信息
            Column.alignItems(HorizontalAlign.End);
        }, Column);
        this.CountdownBadge.bind(this)(DateUtils.daysFromNow(subscription.nextDate));
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.formatDate(subscription.nextDate));
            Text.debugLine("entry/src/main/ets/view/SubscriptionList.ets(110:9)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor(Colors.TEXT_HINT);
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        // 倒计时信息
        Column.pop();
        Row.pop();
    }
    CountdownBadge(daysLeft: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(daysLeft < 0 ? '已过期' :
                daysLeft === 0 ? '今日到期' :
                    `${daysLeft}天后`);
            Text.debugLine("entry/src/main/ets/view/SubscriptionList.ets(128:5)", "entry");
            Text.fontSize(FontSizes.SMALL);
            Text.fontColor('#FFFFFF');
            Text.backgroundColor(daysLeft <= 0 ? Colors.DANGER :
                daysLeft <= 3 ? Colors.WARNING : Colors.SUCCESS);
            Text.padding({ left: 8, right: 8, top: 4, bottom: 4 });
            Text.borderRadius(8);
        }, Text);
        Text.pop();
    }
    DeleteButton(id: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/view/SubscriptionList.ets(145:5)", "entry");
            Button.width(60);
            Button.height('100%');
            Button.backgroundColor(Colors.DANGER);
            Button.borderRadius(Sizes.CARD_RADIUS);
            Button.onClick(async () => {
                try {
                    await promptAction.showToast({ message: '删除成功' });
                    this.onDelete(id);
                }
                catch (error) {
                    console.error('Delete error:', error);
                }
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('删除');
            Text.debugLine("entry/src/main/ets/view/SubscriptionList.ets(146:7)", "entry");
            Text.fontColor('#FFFFFF');
            Text.fontSize(FontSizes.NORMAL);
        }, Text);
        Text.pop();
        Button.pop();
    }
    private formatDate(dateStr: string): string {
        const date = DateUtils.parseDate(dateStr);
        const month = date.getMonth() + 1;
        const day = date.getDate();
        return `${month}月${day}日`;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
