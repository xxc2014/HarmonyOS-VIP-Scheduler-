import { DateUtils } from "@normalized:N&&&entry/src/main/ets/model/Subscription&";
import type { Subscription, CreateSubscriptionRequest, Category } from "@normalized:N&&&entry/src/main/ets/model/Subscription&";
import { StorageService } from "@normalized:N&&&entry/src/main/ets/service/StorageService&";
/**
 * 订阅服务 - 管理订阅的增删改查
 */
export class SubscriptionService {
    private static instance: SubscriptionService = new SubscriptionService();
    private subscriptions: Subscription[] = [];
    private storageService: StorageService = StorageService.getInstance();
    private constructor() { }
    /**
     * 获取单例实例
     */
    static getInstance(): SubscriptionService {
        return SubscriptionService.instance;
    }
    /**
     * 加载所有订阅
     */
    async loadAll(): Promise<Subscription[]> {
        try {
            const data = await this.storageService.getSubscriptions();
            if (data) {
                this.subscriptions = JSON.parse(data) as Subscription[];
            }
            else {
                this.subscriptions = [];
            }
            // 更新所有订阅的下次扣费日期（等待保存完成）
            await this.updateAllNextDates();
            return this.subscriptions;
        }
        catch (error) {
            console.error('SubscriptionService loadAll error:', error);
            this.subscriptions = [];
            return [];
        }
    }
    /**
     * 更新所有订阅的下次扣费日期
     */
    async updateAllNextDates(): Promise<void> {
        let hasChanges = false;
        for (const sub of this.subscriptions) {
            const newNextDate = DateUtils.calculateNextDate(sub.firstDate, sub.cycleType);
            if (newNextDate !== sub.nextDate) {
                sub.nextDate = newNextDate;
                hasChanges = true;
            }
        }
        if (hasChanges) {
            await this.saveAll();
        }
    }
    /**
     * 保存所有订阅
     */
    private async saveAll(): Promise<void> {
        await this.storageService.saveSubscriptions(JSON.stringify(this.subscriptions));
    }
    /**
     * 添加订阅
     */
    async add(request: CreateSubscriptionRequest): Promise<Subscription> {
        const nextDate = DateUtils.calculateNextDate(request.firstDate, request.cycleType);
        const subscription: Subscription = {
            id: DateUtils.generateUUID(),
            name: request.name,
            amount: request.amount,
            cycleType: request.cycleType,
            firstDate: request.firstDate,
            nextDate: nextDate,
            category: request.category,
            remindDays: request.remindDays,
            isActive: request.isActive
        };
        this.subscriptions.push(subscription);
        await this.saveAll();
        return subscription;
    }
    /**
     * 更新订阅
     */
    async update(id: string, request: CreateSubscriptionRequest): Promise<Subscription | null> {
        const index = this.subscriptions.findIndex(s => s.id === id);
        if (index === -1) {
            return null;
        }
        const nextDate = DateUtils.calculateNextDate(request.firstDate, request.cycleType);
        const updated: Subscription = {
            id: id,
            name: request.name,
            amount: request.amount,
            cycleType: request.cycleType,
            firstDate: request.firstDate,
            nextDate: nextDate,
            category: request.category,
            remindDays: request.remindDays,
            isActive: request.isActive
        };
        this.subscriptions[index] = updated;
        await this.saveAll();
        return updated;
    }
    /**
     * 删除订阅
     */
    async delete(id: string): Promise<boolean> {
        const index = this.subscriptions.findIndex(s => s.id === id);
        if (index === -1) {
            return false;
        }
        this.subscriptions.splice(index, 1);
        await this.saveAll();
        return true;
    }
    /**
     * 获取单个订阅
     */
    getById(id: string): Subscription | undefined {
        return this.subscriptions.find(s => s.id === id);
    }
    /**
     * 获取所有订阅
     */
    getAll(): Subscription[] {
        return this.subscriptions;
    }
    /**
     * 获取活跃的订阅
     */
    getActive(): Subscription[] {
        return this.subscriptions.filter(s => s.isActive);
    }
    /**
     * 按分类获取订阅
     */
    getByCategory(category: Category): Subscription[] {
        return this.subscriptions.filter(s => s.category === category);
    }
    /**
     * 获取指定月份的订阅（按nextDate匹配）
     */
    getByMonth(year: number, month: number): Subscription[] {
        const monthPrefix = `${year}-${String(month).padStart(2, '0')}`;
        return this.subscriptions.filter(s => s.nextDate.startsWith(monthPrefix));
    }
}
